package com.codemania.my_application_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    EditText edt_name, edt_age, edt_gender, edt_height, edt_weight;
    Button btn_clear, btn_calculate;
    ImageView imgBMI;

    String name, age, gender, height, weight, data;
    float h = 0.0f;
    float w = 0.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    public void init() {
        edt_name = findViewById(R.id.edt_name);
        edt_age = findViewById(R.id.edt_age);
        edt_gender = findViewById(R.id.edt_gender);
        edt_height = findViewById(R.id.edt_height);
        edt_weight = findViewById(R.id.edt_weight);

        btn_clear = findViewById(R.id.btn_clear);
        btn_calculate = findViewById(R.id.btn_calculate);

        imgBMI = findViewById(R.id.img_bmi);
    }

    public void clear(View v) {
        edt_name.setText("");
        edt_age.setText("");
        edt_gender.setText("");
        edt_height.setText("");
        edt_weight.setText("");
    }

    public void calculate_BMI(View v) {

        if (inputValidation()) {
            float hm = h * 0.3048f;
            float answer = (w / (hm * hm));
            Intent intent = new Intent(MainActivity.this, BMI_Result.class);

            //intent.putExtra("name", name);
            //intent.putExtra("age", age);
            //intent.putExtra("gender", gender);
            //intent.putExtra("height", height);
            //intent.putExtra("weight", weight);
            data = name + ',' + age + ',' + gender + ',' + height + ',' + weight + ',' + String.valueOf(answer) + '\n';
            intent.putExtra("result", answer);
            intent.putExtra("data", data);

            startActivity(intent);
            finish();
            Toast.makeText(this, "Calculating results...", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error! Something went wrong!", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean inputValidation() {

        name = edt_name.getText().toString().trim();
        age = edt_age.getText().toString();
        gender = edt_gender.getText().toString().trim().toLowerCase();
        height = edt_height.getText().toString();
        weight = edt_weight.getText().toString();

        boolean flag1 = name.isEmpty();
        boolean flag2 = age.isEmpty();
        boolean flag3 = gender.isEmpty();

        if (flag1 || flag2 || flag3) {
            Toast.makeText(this, "Error! Fill all requirements!", Toast.LENGTH_SHORT).show();
            if (flag1) {
                edt_name.setError("Error! Name cannot be blank!");
            }
            if (flag2) {
                edt_age.setError("Error! Age cannot be blank!");
            }
            if (flag3) {
                edt_gender.setError("Error! Gender cannot be blank!");
            }
            return false;
        } else {
//            String regexName = "^[\\p{L} .'-]+$";
//            Pattern pName = Pattern.compile(regexName);
//            Matcher mName = pName.matcher(name);
            if (height.isEmpty()) {
                edt_height.setError("Error! Height cannot be blank!");
            } else {
                h = Float.parseFloat(height);
            }
            if (weight.isEmpty()) {
                edt_weight.setError("Error! Weight cannot be blank!");
            } else {
                w = Float.parseFloat(weight);
            }
//
//            flag1 = !mName.matches();
//            flag2 = a < 1 || a > 120;
//            flag3 = !(gender.equals("female") || gender.equals("other") || gender.equals("male"));
//            flag4 = (h < 1.0f || h > 9.0f);
//            flag5 = (w < 10.0f || w > 500.0f);
//
//            if (flag1 || flag2 || flag3 || flag4 || flag5) {
//                Toast.makeText(this, "Error! Enter correct data!", Toast.LENGTH_SHORT).show();
//                if (flag1) {
//                    edt_weight.setError("Error! Invalid name entered!");
//                }
//                if (flag2) {
//                    edt_weight.setError("Error! Invalid age entered!");
//                }
//                if (flag3) {
//                    edt_gender.setError("Error! Invalid gender entered!");
//                }
//                if (flag4) {
//                    edt_height.setError("Error! Invalid height entered!");
//                }
//                if (flag5) {
//                    edt_weight.setError("Error! Invalid weight entered!");
//                }
//                return false;
//            } else {
//            }
            return true;
        }
    }
}
